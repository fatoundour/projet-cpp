#include<iostream>
#include "PieceButin.hpp"
#include<utility>
#include<string>

using namespace std;


PieceButin::PieceButin(string c,pair<int,int> p, int v):Piece{c,p},valeur{v}{};

const int PieceButin::get_valeur() const {return valeur;}

