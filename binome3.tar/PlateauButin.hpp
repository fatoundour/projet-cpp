#ifndef _PLATEAUBUTIN
#define _PLATEAUBUTIN
#include<vector>
#include "Plateau.hpp"

using namespace std;

class PieceButin;

class PlateauButin : public Plateau{
	
	public:
	    //constructeur
	    PlateauButin(const int t);
	    
	    //cette fonction permet de placer les pieces automatiquement su le plateau au debut du jeu
	    void placer_pions();
	    
	    //pour retirer une piece  du plateau qui est à la pos (x,y)
	    bool retirer(int x, int y); 
	    
	    /*teste si la piece à la pos (x,y) peut sauter pour aller à la pos (nx,ny) et */   
	    /*renvoie  la piece qu'il a capturé sinon renvoie nullptr*/
	    PieceButin* peut_sauter(int x , int y , int nx , int ny);
	    
	    //effectue le saut(la capture) si possible et renvoie la piece capturée
	    PieceButin* sauter(int x , int y , int nx , int ny);
	    
	    //calcule la valeur totale des pieces restantes sur le plateau utilisée pour le le score 
	    int calcule_val_pion();
	    
};
#endif
