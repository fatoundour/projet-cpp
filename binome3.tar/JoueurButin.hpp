#ifndef _JoueurButinBUTIN
#define _JoueurButinBUTIN
#include<vector>
#include<utility>
#include<string>

using namespace std;

//Declaration Préalable

class PieceButin;		
class PlateauButin;	

class JoueurButin{

public:    
	//Constructeur  
	JoueurButin(const string n,int s = 0);			
	
	//destructeur  
	virtual ~JoueurButin();	
			
	//Connaitre si le Joueur a le tour de jouer
	bool a_Le_Tour ;	
	 				
	const string get_m_nom() const;	    
	
	int get_m_score() const;	
	    	    
	vector<PieceButin*> get_m_PieceCapturer() const;
	
	//Retirer une piece jaune du Plateau
	bool retirerPieceJaune(int x,int y,PlateauButin& G);	
		    	   
	/*Depuis le Plateau de jeu on récupère la piece à la pos x,y qu'il a choisi et on verifie*/
	/* si c'est une piece jaune et s'il est sur le Plateau si oui renvoie true*/	    	   
	bool choisirPieceJaune(int x,int y,PlateauButin& G);	
	
	//Déplace la piece à la pos (x,y) choisie vers la case à la pos (nx,ny) sur le Plateau
	bool jouerTour(int x, int y,int nx,int ny, PlateauButin &G);	

private:
	//Nom du Joueur
	const string m_nom;				
	//Score du Joueur
	int m_score;				
	//Pieces que le Joueur a capturé	
	vector<PieceButin*> m_PieceCapturer;	
	    
};
#endif
	    
	    
	    
