#include<iostream>
#include"PieceSafari.hpp"
#include"PlateauSafari.hpp"
#include<vector>
#include<utility>
#include<string>

using namespace std;

PlateauSafari::PlateauSafari(const int t):Plateau{t}{};

void PlateauSafari::placer_piece(int x, int y,string n)
{
	pair<int,int> p = {x,y};
	gcase[x][y] = new PieceSafari(n,p);
}

bool PlateauSafari::retirer(int x, int y)
{
	if(gcase[x][y] != nullptr)
	{
	    delete gcase[x][y];
	    gcase[x][y] = nullptr;
	   return true;
	}
	return false;
}

bool PlateauSafari::peut_se_deplacer(int x , int y,int nx,int ny)
{
      /*on verifie si le deplacement de la pos (x,y) à la pos  (nx,ny)  est possible */
	if(gcase[nx][ny] != nullptr)return false;
	
	if(x == nx && y < ny && gcase[nx][ny] != nullptr)
	{
	  int i=y+1;
	  while(i<ny)
	  {
	    if( gcase[nx][i] != nullptr && gcase[nx][i]->get_nom() == "barriere")return false;
	    i++;
	  }
	  return true;
	}
	
	if(x == nx && y > ny && gcase[nx][ny] != nullptr)
	{
	  int i=y-1;
	  while(i>ny)
	  {
	    if( gcase[nx][i] != nullptr && gcase[nx][i]->get_nom() == "barriere")return false;
	    i++;
	  }
	  return true;
	}
	
	if(x < nx && y == ny && gcase[nx][ny] != nullptr)
	{
	  int i=x+1;
	  while(i<nx)
	  {
	    if( gcase[i][y] != nullptr && gcase[i][y]->get_nom() == "barriere")return false;
	    i++;
	  }
	  return true;
	}
	
	if(x > nx && y == ny && gcase[nx][ny] != nullptr)
	{
	  int i=x-1;
	  while(i>nx)
	  {
	    if( gcase[i][y] != nullptr && gcase[i][y]->get_nom() == "barriere")return false;
	    i++;
	  }
	  return true;
	}
	
	return false;
}

bool PlateauSafari::se_deplacer(int x , int y , int nx , int ny)
{
	 
	if(peut_se_deplacer(x,y,nx,ny))
	{
		gcase[x][y]->deplacer_piece(nx,ny);
		gcase[nx][ny] = gcase[x][y];
		gcase[x][y] = nullptr;
		return true;
	}
	return false;
}


	
	
	
	
	
	
	
	
	
	
	    
