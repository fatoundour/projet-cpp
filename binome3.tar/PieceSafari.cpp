#include<iostream>
#include "PieceSafari.hpp"
#include<utility>
#include<string>

using namespace std;


PieceSafari::PieceSafari(string c,pair<int,int> p):Piece{c,p}{est_capturer = false;};


  
