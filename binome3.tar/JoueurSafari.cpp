#include<iostream>
#include"JoueurSafari.hpp"
#include"PieceSafari.hpp"
#include"PlateauSafari.hpp"
#include<vector>
#include<string>

using namespace std;

JoueurSafari::JoueurSafari(const string n,vector<PieceSafari*> p):nom{n},piece{p}
{
   a_Le_Tour = false;
};

JoueurSafari::~JoueurSafari()
{
	for(PieceSafari *e: piece) 
	{ 
	  e = nullptr;
	   delete e;
	}
}

const string JoueurSafari::get_nom() const {return nom;}

vector<PieceSafari*> JoueurSafari::get_piece() const {return piece;}

bool JoueurSafari::placer_piece(int x , int y,PlateauSafari& P)
{
  if(a_Le_Tour)
  {
    P.placer_piece(x,y,piece[0]->get_nom());
    return true;
  }
    return false;
}

bool JoueurSafari::placer_ba(int x , int y,PlateauSafari& P)
{
	if(a_Le_Tour)
	{
	  P.placer_piece(x,y,"barriere");
	  return true;
	}
	return false;
}

bool JoueurSafari::jouer_tour(int x, int y,int nx,int ny, PlateauSafari & P)
{
	if(a_Le_Tour)
	{
	   if(P.se_deplacer(x , y , nx , ny))
	   {  
	     return true;
	   }
	 }
	 return false;
}
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
