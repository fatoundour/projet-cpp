#include<iostream>
#include "PlateauButin.hpp"
#include "PieceButin.hpp"
#include "Piece.hpp"
#include "JoueurButin.hpp"
#include "Plateau.hpp"
#include <SFML/Graphics.hpp>


using namespace std;
using namespace sf;

//variable globale qui permet aux joueurs de retirer une piece jaune au debut de la partie
int nb_tape=0;

//variable globale qui permet de recuperer la position de ancien nuovelle de la piece déplacée
int i,j,ni,nj;

int main()
{
 //génération des instances de classes
      PlateauButin  P(8);
      JoueurButin j1("Joueur1"), j2("Joueur2");
      j1.a_Le_Tour = true;
     
    // Créer une fenêtre SFML
   RenderWindow window(VideoMode(900, 640), "Jeu Butin");
   
    // Boucle principale
    while (window.isOpen()) {
 // Gérer les événements
 Event event;
 while (window.pollEvent(event)) {
     if (event.type == Event::Closed) window.close();
     if(event.type == Event::MouseButtonPressed)
      {
	 nb_tape++;
	 i = ni;
	 j = nj;
	 ni = event.mouseButton.x/80;
	 nj = event.mouseButton.y/80;
	 if(nb_tape<3)
	 {
	    if(j1.retirerPieceJaune(ni,nj,P))
	      {
		  j1.a_Le_Tour = false;
		  j2.a_Le_Tour = true;
	      }
	     else if(j2.retirerPieceJaune(ni,nj,P))
	      {
		  j2.a_Le_Tour = false;
		  j1.a_Le_Tour = true;
	      }
	   }
	   else
	   {
	      j1.jouerTour(i,j,ni,nj,P);
	      j2.jouerTour(i,j,ni,nj,P);
	   }
	 
	}
/*si le joueur ayant le tour de jouer appuie sur le bouton entrée alors il signale la non possibilité de encore jouer avec la piece de départ ou qu'il ne veut plus sauter*/
if(event.type == Event::KeyPressed) 
{
    if (event.key.code == sf::Keyboard::Enter) 
    {
	 if(j1.a_Le_Tour)
	 {
	   j1.a_Le_Tour = false;
	   j2.a_Le_Tour = true;
	   //j1.retirer_pion(G);
	 }
	 else 
	 {
	   j1.a_Le_Tour = true;
	   j2.a_Le_Tour = false;
	   //j2.retirer_pion(G);
	 }
    }
    //fin de partie
    if (event.key.code == sf::Keyboard::F) 
    {
	if(j1.a_Le_Tour)
	 {
	    window.clear(Color::White);
	    Font font;
	    font.loadFromFile("/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf");
	    Text t;
	    t.setFont(font);
	    int x = j2.get_m_score() - P.calcule_val_pion();
	    int y = j1.get_m_score();
	    if(x > y)
	    t.setString("FIN DE PARTI : " + j2.get_m_nom() + " GAGNE " + to_string(x) + " a " + to_string(y));
	    else t.setString("FIN DE PARTI : " + j1.get_m_nom() + " GAGNE " + to_string(y) + " a " + to_string(x));
	    
	    t.setCharacterSize(40);
	    t.setFillColor(Color::Blue);
	    t.setPosition(0,320);
	    window.draw(t);
	    window.display();
	    sleep(seconds(5));
	    window.close();
	    
	 }
	 else 
	 {
	   window.clear(Color::White);
	   Font font;
	   font.loadFromFile("/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf");
	   Text t;
	   t.setFont(font);
	   int x = j1.get_m_score() - P.calcule_val_pion();
	   int y = j2.get_m_score();
	   if(x > y)t.setString("FIN DE PARTI : " + j1.get_m_nom() + " GAGNE " + to_string(x) + " a " + to_string(y));
	   else t.setString("FIN DE PARTI : " + j2.get_m_nom() + " GAGNE " + to_string(y) + " a " + to_string(x));
	   t.setCharacterSize(40);
	   t.setFillColor(Color::Black);
	   t.setPosition(0,320);
	   window.draw(t);
	   window.display();
	   sleep(seconds(5));
	   window.close();
	 }
     }
    	
 }
      
}

 // Effacer l'écran (remplir avec une couleur)
 window.clear(Color::White);

 // Dessiner les cases 
 for(int i =0;i<P.get_taille();i++)
 {
    for(int j =0;j<P.get_taille();j++)
     {
	   // Créer un carré 
	   RectangleShape square(Vector2f(80, 80));
	   square.setFillColor(Color::White);
	   square.setPosition(i*80, j*80);
	   square.setOutlineThickness(3); // Épaisseur de la bordure
    	   square.setOutlineColor(Color::Black); // Couleur de la bordure
           window.draw(square);
      }
 }
	
//dessiner les pions
for(int i =0;i<P.get_taille();i++)
{
    for(int j =0;j<P.get_taille();j++)
      {
	// Créer un cercle
        PieceButin* p = static_cast<PieceButin*>(P.get_gcase()[i][j]);
        if(p!=nullptr){
        int x = p->get_pos().first;
        int y = p->get_pos().second;
        CircleShape shape;
	shape.setRadius(30);
	shape.setOrigin(x+40, y+40);
	if(p->get_nom() == "Red") shape.setFillColor(Color::Red);
        else if(p->get_nom() == "Yellow") shape.setFillColor(Color::Yellow);
	else shape.setFillColor(Color::Black);
 	shape.setPosition(x*80 + 52, y*80 + 52); 
        window.draw(shape);
        }
      }
   
}
      
  // afficher le joueur ayant le tour
  Font font;
  font.loadFromFile("/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf");
  Text t;
  t.setFont(font);
  if(j1.a_Le_Tour)t.setString("Tour du joueur : " + j1.get_m_nom());
  else t.setString("Tour du joueur : " + j2.get_m_nom());
  t.setCharacterSize(20);
  t.setFillColor(Color::Black);
  t.setPosition(650, 0);
  window.draw(t);
 // Afficher ce qui a été dessiné
 
 window.display();
}

    return 0;
}



