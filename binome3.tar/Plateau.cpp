#include<iostream>
#include"Plateau.hpp"
#include"Piece.hpp"
#include<vector>
#include<string>

using namespace std;



Plateau::Plateau(const int t):taille{t}
{
	gcase = vector<vector<Piece*>>(t,vector<Piece*>(t,nullptr));
};

Plateau::~Plateau()
{
	for(vector<Piece*> l : gcase)
	{
		for(Piece* p : l)
		{
		     delete p;
		     p = nullptr;
		}
	}
}


const int Plateau::get_taille() const {return taille;}

vector<vector<Piece*>> Plateau::get_gcase() const {return gcase;}
             
