#include<iostream>
#include"PieceButin.hpp"
#include"PlateauButin.hpp"
#include<vector>
#include<utility>
#include <algorithm>
#include <random>
using namespace std;



PlateauButin::PlateauButin(const int h):Plateau{h}
{
	placer_pions();
};


void PlateauButin::placer_pions()
{
  //vecteur contenant la position des cases de la PlateauButin
  vector<pair<int,int>> vec;
  pair<int,int> p;
  for(int i = 0;i<taille;i++)
  {
  	for(int j=0;j<taille;j++)
  	{
  		p = {i,j};
  		vec.push_back(p);
  		
  	}
  }
  
   // Initialisation du générateur de nombres aléatoires
    std::random_device rd;
    std::mt19937 gen(rd());
    // Mélanger l'ordre des éléments dans le vecteur
    shuffle(vec.begin(), vec.end(), gen);
    //definition des positon pour chaque pion sur le PlateauButin de manière aléatoire
    int k,f,s;
      for(int i = 0;i<taille;i++)
  	{
  		for(int j = 0;j<taille;j++)
  		{
  			k = i*taille+j;
  			f = vec[k].first;
  			s = vec[k].second;
  			if(k<34)
  			{
  			   gcase[f][s] = new PieceButin("Yellow",vec[k],3);
  			}
  			
  			else if(k>=34 && k<54)
  			{
  			   gcase[f][s] = new PieceButin("Red",vec[k],2);
  			}
  			
  			else
  			{
  			   gcase[f][s] = new PieceButin("Black",vec[k],1);
  			}
  		}
  	}
  	
}


bool PlateauButin::retirer(int x, int y)
{
	if(gcase[x][y] != nullptr)
	{
	    delete gcase[x][y];
	    gcase[x][y] = nullptr;
	   return true;
	}
	return false;
}

PieceButin* PlateauButin::peut_sauter(int x , int y,int nx,int ny)
{
	/* Dans cette fonction on verifie si la pos (nx,ny) qu'on veut aller est dans */    
	/* dans l'ensemble des deplacement possibles depuis la pos (x,y) si oui et que la case*/
	/* sauter n'est pas vide on renvoie la piece de cette case sinon on renvoie nullptr*/
	
	if(gcase[nx][ny] != nullptr)return nullptr;
	
	if(x == nx && y==ny-2 && gcase[x][y+1] != nullptr)
	return static_cast<PieceButin*>(gcase[x][y+1]);
	
	if(x == nx && y==ny+2 && gcase[x][y-1] != nullptr)
	return static_cast<PieceButin*>(gcase[x][y-1]);
	
	if(x == nx-2 && y==ny && gcase[x+1][y] != nullptr)
	return static_cast<PieceButin*>(gcase[x+1][y]);
	
	if(x == nx+2 && y==ny && gcase[x-1][y] != nullptr)
	return static_cast<PieceButin*>(gcase[x-1][y]);
	
	if(x == nx+2 && y==ny-2 && gcase[x-1][y+1] != nullptr)
	return static_cast<PieceButin*>(gcase[x-1][y+1]);
	
	if(x == nx+2 && y==ny+2 && gcase[x-1][y-1] != nullptr)
	return static_cast<PieceButin*>(gcase[x-1][y-1]);
	
	if(x == nx-2 && y==ny+2 && gcase[x+1][y-1] != nullptr)
	return static_cast<PieceButin*>(gcase[x+1][y-1]);
	
	if(x == nx-2 && y==ny-2 && gcase[x+1][y+1] != nullptr)
	return static_cast<PieceButin*> (gcase[x+1][y+1]);
	return nullptr;
}

PieceButin* PlateauButin::sauter(int x , int y , int nx , int ny)
{
	PieceButin * p = peut_sauter(x,y,nx,ny);
	if(p!= nullptr)
	{
		gcase[x][y]->deplacer_piece(nx,ny);
		gcase[nx][ny] = gcase[x][y];
		gcase[x][y] = nullptr;
		return p;
	}
	return p;
}

int PlateauButin::calcule_val_pion()
{
  int s = 0;
  for(int i = 0;i<taille;i++)
  	{
  		for(int j = 0;j<taille;j++)
  		{
  			if(gcase[i][j] != nullptr) s = s + static_cast<PieceButin*>(gcase[i][j])->get_valeur();
  		}
  	}
  	return s;
}
	
	
	
	
	
	
	
	
	
	
	
	    
