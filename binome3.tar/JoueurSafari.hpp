#ifndef _JOUEURSAFARI
#define _JOUEURSAFARI
#include<vector>
#include<utility>
#include<string>

using namespace std;

class PieceSafari;
class PlateauSafari;


class JoueurSafari {
	   
	public:
	     
	     //constructeur
	    JoueurSafari(const string n,vector<PieceSafari*> p);
	    
	    //destructeur 
	    virtual ~JoueurSafari(); 
	    
	    //determine si le joueur est à son tour de jouer
	     bool a_Le_Tour; 
	    
	    // recuperer le nom du joueur
	    const string get_nom() const; 
	    
	    // recuperer le vecteur de piece du joueur
	    vector<PieceSafari*> get_piece() const; 
	 
	    //place une piece sur le plateau à la position (x,y)
	    bool placer_piece(int x , int y,PlateauSafari& P); 
	    
	    //place une barrière sur le plateau à la position (x,y)
	    bool placer_ba(int x , int y,PlateauSafari& P); 
	    
	    //deplace la pièce à la pos (x,y) vers la position  (nx,ny) sur la grille
	    bool jouer_tour(int x, int y,int nx,int ny, PlateauSafari& P);
	    
	protected:
	    //nom du joueur
	    const string nom; 
	    
	    //pieces que le joueur a capturé ou doit jouer
	    vector<PieceSafari*> piece; 
	  
};
#endif
	    
	    
	    
