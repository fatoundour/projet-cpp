#ifndef _PIECEBUTIN
#define _PIECEBUTIN
#include"Piece.hpp"
#include<vector>
#include<utility>
#include<string>

using namespace std;


class PieceButin : public Piece{
	
	public:
	  //constructeur
	  PieceButin(string c,pair<int,int> p,int v);
	  
	  const int get_valeur() const;
	  
	  private:
	    //valeur apportée par la piece
	    const int valeur;
	    
};
#endif
	    
