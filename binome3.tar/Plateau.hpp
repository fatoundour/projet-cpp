#ifndef _PLATEAU
#define _PLATEAU
#include<vector>
#include<string>
using namespace std;

class Piece;

class Plateau{
	
	public:
	    //constructeur
	    Plateau(const int t);
	    
	    //destructeur
	    virtual ~Plateau();
	    
	    const int get_taille() const;
	    
	    vector<vector<Piece*>> get_gcase() const;
	    
	protected:
	    //represente la taille du plateau
	    const int taille;
	    
	    //vector de vector de pointeur de pieces qui sont sur le plateau
	    vector<vector<Piece*>> gcase;
};

#endif
