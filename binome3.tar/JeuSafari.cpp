#include<iostream>
#include "PlateauSafari.hpp"
#include "PieceSafari.hpp"
#include "JoueurSafari.hpp"
#include <SFML/Graphics.hpp>
#include<vector>
#include <algorithm>
#include <random>

using namespace std;
using namespace sf;

//variable globale qui permet aux joueurs de retirer un pion jaune au debut de la partie
int nb_tape=0;

//variable globale qui permet de recuperer la position de l'ancien et de la nouvelle piece cliquée
int i,j,ni,nj;

int main()
{
  //definition du tableau de barriere
  vector<PieceSafari*> tab_ba(50,nullptr) ;
  for(int i = 0 ; i<50;i++)tab_ba[i] = new PieceSafari("barriere",{0,0});
  //attribution des pieces aux joueur
  vector<PieceSafari*> E(3,nullptr) ;
  E[0] = new PieceSafari("Elephant",{0,0});
  E[1] = new PieceSafari("Elephant",{0,0});
  E[2] = new PieceSafari("Elephant",{0,0});
  
  vector<PieceSafari*> R(3,nullptr) ;
  R[0] = new PieceSafari("Rhinoceros",{0,0});
  R[1] = new PieceSafari("Rhinoceros",{0,0});
  R[2] = new PieceSafari("Rhinoceros",{0,0});
  
  vector<PieceSafari*> L(3,nullptr) ;
  L[0] = new PieceSafari("Lion",{0,0});
  L[1] = new PieceSafari("Lion",{0,0});
  L[2] = new PieceSafari("Lion",{0,0});
 
  vector<vector<PieceSafari*>> vec = {E,R,L};
  
   // Initialisation du générateur de nombres aléatoires
   std::random_device rd;
   std::mt19937 gen(rd());
    
   // Mélanger l'ordre des éléments dans le vecteur
   shuffle(vec.begin(), vec.end(), gen);
    
   //génération des instances de classes : on initialise un plateau 16x16 dont les 8x8 sont les cases des animaux et le reste pour les barrières
    PlateauSafari  P(17);
    JoueurSafari j1("Joueur1",vec[0]), j2("Joueur2",vec[1]), j3("Joueur3",vec[2]);
    j1.a_Le_Tour = true;
    // Créer une fenêtre SFML
    RenderWindow window(VideoMode(1010, 900), "Jeu Safari");
   
    // Boucle principale
    while (window.isOpen()) {
    // Gérer les événements
    Event event;
    while (window.pollEvent(event)) {
    if (event.type == Event::Closed) window.close();
    if(event.type == Event::MouseButtonPressed)
    {
     nb_tape++;
     i = ni;
     j = nj;
     ni = event.mouseButton.x/40;
     nj = event.mouseButton.y/40;
     if(nb_tape<=18)
     {
      if(ni%2!=0 && nj%2!=0)
       {
        j1.placer_piece(ni,nj,P);
        j2.placer_piece(ni,nj,P);
        j3.placer_piece(ni,nj,P);
        }
      if((ni%2==0 && nj%2!=0) || (ni%2!=0 && nj%2==0))
      { 
       if(!tab_ba.empty())
       {
         if (j1.placer_ba(ni,nj,P))
          { 
            tab_ba.pop_back();
	    j1.a_Le_Tour = false;
	    j2.a_Le_Tour = true;
	  }
	  else if (j2.placer_ba(ni,nj,P))
          {
           tab_ba.pop_back();
	   j2.a_Le_Tour = false;
	   j3.a_Le_Tour = true;
	  }
	  else if (j3.placer_ba(ni,nj,P))
          { 
            tab_ba.pop_back();
	    j3.a_Le_Tour = false;
	    j1.a_Le_Tour = true;
	  }
	}  	       
      }
    }
   else
    {
       if(ni%2!=0 && nj%2!=0)
       {
         j1.jouer_tour(i,j,ni,nj,P);
         j2.jouer_tour(i,j,ni,nj,P);
         j3.jouer_tour(i,j,ni,nj,P);
       }        	            	      
              	      
     }
        if((ni%2==0 && nj%2!=0) || (ni%2!=0 && nj%2==0))
         { 
	  if(!tab_ba.empty())
           {
	     if (j1.placer_ba(ni,nj,P))
	      { 
	        tab_ba.pop_back();
		j1.a_Le_Tour = false;
		j2.a_Le_Tour = true;
	      }	  
	      else if (j2.placer_ba(ni,nj,P))
	      {
		tab_ba.pop_back();
		j2.a_Le_Tour = false;
		j3.a_Le_Tour = true;
	      }	   
	      else if (j3.placer_ba(ni,nj,P))
	      {
		tab_ba.pop_back();
		j3.a_Le_Tour = false;
		j1.a_Le_Tour = true;
	      }
	    }
              	       
          }      	         	 
    }
  }    


        // Effacer l'écran (remplir avec une couleur)
        window.clear(Color::White);

	// Dessiner les cases 
        for(int i =0;i<P.get_taille();i++)
	   {
	      for(int j =0;j<P.get_taille();j++)
	        {
	          // Créer un carré 
		    RectangleShape square(Vector2f(40, 40));
		    if(i%2!=0 && j%2!=0)square.setFillColor(Color(139, 69, 19));//cases des animaux
		    else if(i%2==0 && j%2==0)square.setFillColor(Color::Black);//cases non jouables
		    else square.setFillColor(Color::White);//cases des barrières
		    square.setPosition(i*40, j*40);
		    square.setOutlineThickness(3); // Épaisseur de la bordure
    		    square.setOutlineColor(Color::Black); // Couleur de la bordure
                    window.draw(square);
		}
	}
	    
	//dessiner les pieces de chaque joueur
	for(int i =0;i<P.get_taille();i++)
	   {
	      for(int j =0;j<P.get_taille();j++)
	        {
	            Texture a;
	            Sprite s;
	            // Créer un cercle
                    PieceSafari* p = static_cast<PieceSafari*>(P.get_gcase()[i][j]);
                    if(p!=nullptr){
		    if(p->get_nom() == "Rhinoceros")
		    {
		       // Chargement de l'image de la piece
		      a.loadFromFile("rhino.png");
		      s.setTexture(a);
		      s.setScale(0.3, 0.3);
		      s.setPosition(i*40+5, j*40+6); // Position du logo de l'animal sur la pièce
		    }
		    else if(p->get_nom() == "Lion")
		    {
		       // Chargement de l'image de la piece
		      a.loadFromFile("lion.png");
		      s.setTexture(a);
		      s.setScale(0.2, 0.15);
		      s.setPosition(i*40+3, j*40+4); // Position du logo de l'animal sur la pièce
		    }
		    else if(p->get_nom() == "Elephant")
		    {
		      // Chargement de l'image de la piece
		      a.loadFromFile("ele.png");
		      s.setTexture(a);
		      s.setScale(0.3, 0.3);
		      s.setPosition(i*40+5, j*40+8); // Position du logo de l'animal sur la pièce
		    }
		    
		     else 
		    {
		      // Chargement de l'image de la piece
		      a.loadFromFile("bar.png");
		      s.setTexture(a);
		      s.setScale(0.5, 0.5);
		      s.setPosition(i*40+7, j*40+7); // Position du logo de la barriere sur la pièce
		    }
                    window.draw(s);
                    }
                 }
                 
             }
             
         // afficher le joueur ayant le tour
         Font font;
         font.loadFromFile("/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf");
         Text t;
   	 t.setFont(font);
    	 if(j1.a_Le_Tour)t.setString("Tour du joueur : " + j1.get_nom()+ " " + j1.get_piece()[0]->get_nom());
    	 else if(j2.a_Le_Tour) t.setString("Tour du joueur : " + j2.get_nom()+ " " + j2.get_piece()[0]->get_nom());
    	 else t.setString("Tour du joueur : " + j3.get_nom()+ " " + j3.get_piece()[0]->get_nom());
   	 t.setCharacterSize(20);
    	 t.setFillColor(Color::Black);
    	 t.setPosition(680, 0);
    	 window.draw(t);
        // Afficher ce qui a été dessiné
        
        window.display();
    }

    return 0;
}



