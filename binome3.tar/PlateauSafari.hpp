#ifndef _PLATEAUSAFARI
#define _PLATEAUSAFARI
#include<vector>
#include<string>
#include"Plateau.hpp"

using namespace std;

class PieceSafari;

class PlateauSafari : public Plateau{
	public:
	    //constructeur
	    PlateauSafari(const int t);
	    
	    // placer une  piece sur le plateau à la position x,y
	    void placer_piece(int x , int y, string n);
	    
	    //pour retirer une piece du plateau qui est à la pos (x,y)
	    bool retirer(int x, int y); 
	    
	    //teste si la piece à la pos (x,y) peut se deplacer pour aller à la pos (nx,ny) 
	    bool peut_se_deplacer(int x , int y , int nx , int ny);
	    
	    //effectue le le deplacement si possible de (x,y) vers (nx,ny)
	    bool se_deplacer(int x , int y , int nx , int ny);
	    
};
#endif
