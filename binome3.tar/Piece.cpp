#include<iostream>
#include "Piece.hpp"
#include<utility>
#include<string>

using namespace std;


Piece::Piece(string c,pair<int,int> p):nom{c},pos{p}{};

const string Piece::get_nom() const {return nom;}

pair<int,int> Piece::get_pos() const {return pos;}

void Piece::deplacer_piece(int nx, int ny) {pos = {nx,ny};}

  
