# projet-cpp 


Ce projet consiste à développer trois jeux variants de Dames en utilisant les notions connues en C++: 
Jeux 1 Butin 
Jeux 2 Dames
Jeux 3 Safari

Pour se faire on les a représenté sous formes  classes inter-dépendantes:
On est parti sur trois classes méres : la classe Piece , la classe Plateau et la classe Joueur ensuite on a derivé les autres classes à partir de ces trois.

Un Makefile est créé pour commpiler l'ensemble des programmmes en tapant juste la commande make.Pour chaque jeu est créé alors l'executable.

Pour lancer l'execution il suffit de taper la commande ./nom_fichier_exec avec nom_fichier_exec le nom de l'executable du jeux concerné.

**utilisation de Safari**

Une fois que le jeux est lancé, deux instances de la classe joueur sont créées Joueur1 et Joueur2.
Chaque joueur a son tour visible sur la fenetre du terminal à droite .Au debut le Joueur1 a le tour, et il enléve une pièce jaune uniquement et le tour est automatiquement donné au Joueur2 lui aussi retire une piéce jaune et maintenant le tour est au Joueur1.

À son tour, Le Joueur1 choisit une piece jaune qui lui permettra de capturer un ou plusieurs pièce(s) de toutes couleurs. À chaque saut la pièce capturée est enlevée du plateau.
Si il ne peut plus sauter de pièce , il passe le tour au Joueur2 en appuyant sur le bouton "Enter".
On fait pareil pour Joueur2.

Si le joueur qui a le dernier tour ne peut plus capturer de pièce quelque soit la pièce jaune choisie alors il déclare la fin du parti en appuyant sur le bouton "F" comme "Fin" et un texte apparait sur la fenetre indiquant le score du joueur gagnant.

**utilisation de Butin**

Aprés avoir compilé les fichiers et lancé le programme, on a une grille à trois couleurs marron, noir et blanc. Les cases marrons sont les cases ou on place les pieces(animaux) ,ils sont entourées de gauche à droite, de haut en bas par les cases blancs(barrières). Les cases noir ne sont pas jouables on n'y mets rien.

Sur la fenetre du jeu est affiché le joueur qui a le tour et l'animal qu'il a choisi. À son tour, il place un animal sur une case marron et une barrière sur une case blanc jusqu'à ce que tout ses piéces soient placées sur la grille du jeu. Donc la partie comme



