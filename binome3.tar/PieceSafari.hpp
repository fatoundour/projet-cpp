#ifndef _PIECESAFARI
#define _PIECESAFARI
#include<vector>
#include<utility>
#include<string>
#include"Piece.hpp"

using namespace std;


class PieceSafari:public Piece{
	public:
	
	  //permet de savoir si lapiece animale est capturée
	  bool est_capturer;
	  
	  //constructeur
	  PieceSafari(string c,pair<int,int> p);
};
#endif
	    
