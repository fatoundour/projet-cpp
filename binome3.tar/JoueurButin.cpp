#include<iostream>
#include"JoueurButin.hpp"
#include"PieceButin.hpp"
#include"PlateauButin.hpp"
#include<vector>
#include<string>

using namespace std;

JoueurButin::JoueurButin(const string n, int s):m_nom{n},m_score{s}
{
	a_Le_Tour = false;
	m_PieceCapturer= vector<PieceButin*>(64,nullptr);
}; 

JoueurButin::~JoueurButin()
{
	for(PieceButin *e: m_PieceCapturer) 
	{ 
	   e = nullptr;
	   delete e;
	}
}

const string JoueurButin::get_m_nom() const {return m_nom;}

int JoueurButin::get_m_score() const {return m_score;}

vector<PieceButin*> JoueurButin::get_m_PieceCapturer() const {return m_PieceCapturer;}

bool JoueurButin::retirerPieceJaune(int x,int y,PlateauButin& G)
{
	if(a_Le_Tour && G.get_gcase()[x][y] != nullptr && G.get_gcase()[x][y]->get_nom() == "Yellow")
	{
		G.retirer(x,y);
		return true;
	}
	return false;
}

bool JoueurButin::choisirPieceJaune(int x,int y,PlateauButin& G)
{
	if(G.get_gcase()[x][y] != nullptr && G.get_gcase()[x][y]->get_nom() == "Yellow")
	{
		return true;
	}
	return false;
}
bool JoueurButin::jouerTour(int x, int y,int nx,int ny, PlateauButin & G)
{
	if(a_Le_Tour)
	{
	   if(choisirPieceJaune(x,y,G))
	   {
	     PieceButin* q = G.sauter(x,y,nx,ny);
	     
	     //ici q represente le pion capturé(sauté)
	     if(q!=  nullptr)//c'est à dire qu'il a sauté q
	     {
	       m_PieceCapturer.push_back(q);
	       m_score = m_score + q->get_valeur();
	       
	       //on retire apres le pion capturé de la Plateau
	       G.retirer(q->get_pos().first, q->get_pos().second);
	       
	     }
	   }
	 }
	 return false;
}
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
