#ifndef _PIECE
#define _PIECE
#include<vector>
#include<utility>
#include<string>

using namespace std;


class Piece{

	public:
	  //constructeur
	  Piece(string c,pair<int,int> p);
	  
	  const string get_nom() const;
	  
	  pair<int,int> get_pos() const;
	  
	  // pour deplacer une piece à la pos (nx,ny)
	  void deplacer_piece(int nx, int ny);
	  
	protected:
	    //nom de la piéce determiné par la couleur ou le type
	    const string nom;
	    
	    //position de la piece sur la grille
	    pair<int,int> pos;
};
#endif
	    
